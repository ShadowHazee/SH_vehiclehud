Config = {}

Config.SpeedUnit = 'kmh'  -- Use 'kmh' for kilometers or 'mph' for miles
Config.HudPosition = 'right'  -- Use 'right' for default position or 'left' for position near the map
Config.AutoMinimap = true --